#jeeshop

简介：jeeshop是一套使用Java语言开发的独立网店系统，jeeshop致力于为个人或企业提供免费、好用的网店系统系统，该系统采用较为流行的J2EE框架 struts2+ myBatis+ spring 进行合理的组合开发,欢迎学习和试用。


<div>
    				<h4 style="font-weight: 400px;"><span class="glyphicon glyphicon-info-sign"></span>&nbsp;&nbsp;jeeshop系统主要特性：</h4>
					<ul style="margin-left: 0px;-webkit-padding-start: 10px;">
						<li class="jeeshop_item "><span>支持多种前台样式，可以方便的在后台切换。</span></li>
						<li class="jeeshop_item "><span>支持大部分配置信息后台管理，减少修改配置文件造成的问题和不必要的麻烦。</span></li>
						<li class="jeeshop_item "><span>支持灵活的商品目录管理、商品管理、商品属性、商品参数的管理。</span></li>
						<li class="jeeshop_item "><span>支持系统文章、公告、活动的发布。格式可为文本、图片、视频等。</span></li>
						<li class="jeeshop_item "><span>支持管理员对订单的整个生命周期。包括确认订单、发货、签收、归档、取消、修改收货人地址等操作。</span></li>
						<li class="jeeshop_item "><span>支持会员等级。会员等级包括：普通会员、高级会员、铜牌会员、金牌会员、银牌会员，等五个等级。</span></li>
						<li class="jeeshop_item "><span>支持支付宝担保交易支付。</span></li>
						<li class="jeeshop_item "><span>支持本地会员、QQ、新浪微博、支付宝快捷等信任登陆方式。</span></li>
						<li class="jeeshop_item "><span>支持通过邮箱找回密码功能。</span></li>
						<li class="jeeshop_item "><span>支持像京东、淘宝那样的左侧吸附功能的商品类目展示方式。</span></li>
						<li class="jeeshop_item "><span>支持商品收藏、商品到货邮件提醒。</span></li>
						
						<li class="jeeshop_item "><span>支持商品促销活动功能，促销活动主要包括 降价促销、打折促销、买就增双倍积分。</span></li>
						<li class="jeeshop_item "><span>支持积分商城功能，用户可以通过积分兑换到想要购买的商品了。</span></li>
						<li class="jeeshop_item "><span>支持商品规格功能，例如服装，手机等商品都有对商品规格的要求。</span></li>
						<li class="jeeshop_item "><span>...</span></li>
						

					</ul>
				</div>


官网地址：http://www.jeeshop.net

demo演示环境地址：

大屏幕：http://demo.jeeshop.net/?responsive=y

小屏幕：http://demo.jeeshop.net/?responsive=n

下载地址：http://yun.baidu.com/share/link?shareid=1009909610&uk=2770653384