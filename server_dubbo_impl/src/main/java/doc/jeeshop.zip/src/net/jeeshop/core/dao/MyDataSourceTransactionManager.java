package net.jeeshop.core.dao;

import org.springframework.jdbc.datasource.DataSourceTransactionManager;

public class MyDataSourceTransactionManager extends DataSourceTransactionManager{
	
}
