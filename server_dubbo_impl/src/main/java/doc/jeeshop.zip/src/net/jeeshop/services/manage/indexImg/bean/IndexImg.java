package net.jeeshop.services.manage.indexImg.bean;

import java.io.Serializable;

import net.jeeshop.core.dao.page.PagerModel;

public class IndexImg extends net.jeeshop.services.common.IndexImg implements Serializable {

	@Override
	public void clear() {
		super.clear();
	}

}
