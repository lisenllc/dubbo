package net.jeeshop.core.listener;

public interface CallBack {
	String callback() throws Exception;
}
